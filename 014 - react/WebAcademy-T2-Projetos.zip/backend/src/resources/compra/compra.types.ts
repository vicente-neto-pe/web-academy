export interface ProdutoCarrinho {
  id: string;
  quantidade: number;
}
