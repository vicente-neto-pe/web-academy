export const DEFAULT_LANGUAGE = "pt-BR";
