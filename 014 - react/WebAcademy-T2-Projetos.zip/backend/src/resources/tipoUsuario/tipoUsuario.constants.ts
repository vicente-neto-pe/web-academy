export enum TiposUsuarios {
  ADMIN = "7edd25c6-c89e-4c06-ae50-c3c32d71b8ad",
  CLIENT = "6a4cda94-fbb6-476b-be29-f4124cae9058",
}
