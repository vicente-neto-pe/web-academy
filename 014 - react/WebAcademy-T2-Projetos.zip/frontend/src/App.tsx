import "./App.css";

function App() {
  return <h1>CURSO [REACT WEB ACADEMY 🖥️]</h1>;
}

export default App;
