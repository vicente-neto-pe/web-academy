import { useDispatch, useSelector } from "react-redux";
import "./App.css";
import { RootState } from "./redux/store";
import { deleteProduct } from "./redux/slices/produto.slice";

function App() {
  const produtos = useSelector((state: RootState) => state.produtos);
  const dispatch = useDispatch();

  return (
    <div className="App" style={{ display: "flex", flexDirection: "row" }}>
      <div style={{ backgroundColor: "red" }}>
        {produtos.map((produto) => {
          return (
            <div key={produto.id}>
              {produto.title}
              <button onClick={() => dispatch(deleteProduct(produto.id))}>
                Apagar
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default App;
