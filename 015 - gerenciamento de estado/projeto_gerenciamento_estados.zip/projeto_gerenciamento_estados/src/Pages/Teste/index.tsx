import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";

export function Componente1() {
  const produtos = useSelector((state: RootState) => state.produtos);

  return (
    <div>
      {produtos.map((produto) => {
        return <div key={produto.id}>{produto.title}</div>;
      })}
    </div>
  );
}
