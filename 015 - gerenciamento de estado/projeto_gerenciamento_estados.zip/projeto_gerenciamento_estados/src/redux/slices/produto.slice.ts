import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { Produto, ProdutosMock } from "../../mock/produtos.mock";

const initialStateProdutoSlice: Produto[] = ProdutosMock;

export const produtoSlice = createSlice({
  name: "produtoSlice",
  initialState: initialStateProdutoSlice,
  reducers: {
    deleteProduct(state, action: PayloadAction<number>) {
      return state.filter((produto) => produto.id !== action.payload);
    },
  },
});
export const { deleteProduct } = produtoSlice.actions;
export default produtoSlice.reducer;
